default['jboss7']['jboss_home'] = '/opt'
default['jboss7']['jboss_dir'] = 'jboss'
default['jboss7']['tmp'] = '/tmp'
default['jboss7']['jboss_zip'] = 'jboss-as-7.1.1.Final.zip' 
default['jboss7']['version'] = '7.1.1'
default['jboss7']['dl_url'] = "download.jboss.org/jbossas/7.1/jboss-as-7.1.1.Final/jboss-as-7.1.1.Final.zip"

default['jboss7']['download_app'] = 'http://www.cumulogic.com/download/Apps/testweb.zip'
default['jboss7']['app_zip'] = 'testweb.zip'
default['jboss7']['jboss_user'] = 'jboss'
default['jboss7']['jboss_ip'] = '127.0.0.1'  
